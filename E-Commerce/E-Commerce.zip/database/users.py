class User:
	def __init__(
		self, name: str, id: str, favourites: list, cart: list,
		address: str, gender: int, city_code: int, fav_categories: list,
		orders: list, joined_in: str
	):

		self.id= id
		self.name= name
		self.favourites= favourites
		self.fav_categories= fav_categories
		self.cart= cart
		self.address= address
		self.gender= gender
		self.city_code= city_code
		self.orders= orders
		self.joined_in= joined_in



class Users:
	def __init__(self):
		import datetime
		self.all_users: list= [User(
			id="dsfsdfsdfs",
			name="User Name",
			favourites= [
				"dsfsdlfsdfscss",
				"dsfsdlfsdfscss",
				"dsfsdlfsdfscss",
				"dsfsdlfsdfscss",
				"dsfsdlfsdfscss",
				"dsfsdlfsdfscss",
			],
			fav_categories= [],
			cart= [
				"dsfsdlfsdfscss",
				"dsfsdlfsdfscss",
				"dsfsdlfsdfscss",
				"dsfsdlfsdfscss",
				"dsfsdlfsdfscss",
				"dsfsdlfsdfscss",
				"dsfsdlfsdfscss",
				"dsfsdlfsdfss",
				"dsfsdlfsdfss",
				"dsfsdlfsdfss",
				"dsfsdlfsdfss",
				"dsfsdlfsdfss",
				"dsfsdlfsdfss",
				"dsfsdlfsdfss",
				"dsfsdlfsdfs",
				"dsfsdlfsdfasda",
				"dsfsdlfsdfasda",
				"dsfsdlfsdfasda",
				"xdsfsdlfsdfscss",
				"xdsfsdlfsdfscss",
				"xdsfsdlfsdfscss",
				"xdsfsdlfsdfscss",
				"xdsfsdlfsdfscss",
				"xdsfsdlfsdfscss",
				"xdsfsdlfsdfscss",
				"xdsfsdlfsdfss",
				"xdsfsdlfsdfss",
				"xdsfsdlfsdfss",
				"xdsfsdlfsdfss",
				"xdsfsdlfsdfss",
				"xdsfsdlfsdfss",
				"xdsfsdlfsdfss",
				"xdsfsdlfsdfs",
				"xdsfsdlfsdfasda",
				"xdsfsdlfsdfasda",
				"xdsfsdlfsdfasda",
			],
			address= "User Address",
			gender= 0,
			city_code= 0,
			orders= [],
			joined_in= str(datetime.date.today())
		) for _ in range(0, 10)]


	def get_user_by_id(self, uid: str):
		return self.all_users[0]