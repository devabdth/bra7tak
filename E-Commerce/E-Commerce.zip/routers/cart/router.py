import sys
sys.path.insert(0, '../')

from flask import Flask, render_template, session

from config import Config
from layout.layout import Layout
from database.database import Database
from content import Content
from utils import Utils


class CartRouter:
    def __init__(self, app: Flask):
        self.app= app
        self.layout: Layout= Layout()
        self.cfg: Config= Config()
        self.database: Database= Database()
        self.content: Content= Content()
        self.utils: Utils= Utils()


    def setup(self):
        self.assign_cart_router()


    def assign_cart_router(self):
        @self.app.route('/cart/', methods= ["get"])
        def cart_index():
            lang = session.get("LANG", "ar")
            uid= session.get("CURRENT_USER_ID", None)
            if lang == 'en':
                primary_font_family= 'Raleway'
                second_font_family= 'Poppins'
            elif lang == 'ar':
                primary_font_family= 'Cairo'
                second_font_family= 'Cairo'
            if uid is None:
                user_data= self.database.users.get_user_by_id(uid)
                return render_template(
                	'cart/index.html',
                    cart= self.utils.cart_calculations(user_data.cart, city_code= user_data.city_code),
                    utils= self.utils,
            		uid= uid,
            		user_data= user_data,
            		lang= lang,
            		cfg= self.cfg,
            		content= self.content,
            		primary_font_family= primary_font_family,
            		second_font_family= second_font_family,
            		len= len,
            		database= self.database,
            		layout= self.layout
            	)
            return render_template(
                'cart/index.html',
            	lang= lang,
            	cfg= self.cfg,
            	content= self.content,
            	primary_font_family= primary_font_family,
            	second_font_family= second_font_family,
            	len= len,
            	database= self.database,
            	layout= self.layout
            )



