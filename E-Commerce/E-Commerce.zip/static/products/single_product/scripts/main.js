let slideShowSlides;
const initializeSlideShow = (listSource, baseUrl) => {
    const currentSlide = document.getElementById('current-slide');

    slideShowSlides = listSource.map(item => document.getElementById(item));
    console.log(slideShowSlides);
    slideShowSlides.map(slide => {
        slide.onclick= () => {
            if (slide.classList.contains('active-slide')) {
                return;
            }

            slideShowSlides.map(slide_ => {
                slide_.classList.remove('active-slide');
            });

            slide.classList.add('active-slide');
            currentSlide.style.backgroundImage = `url(${baseUrl}/assets/products/name/${slide.id}/)`;
        }
        
    });
}