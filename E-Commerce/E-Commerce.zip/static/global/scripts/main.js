

const changeLang = async (url, newLang) => {
    console.log("Clicked");
    await fetch(`${url}/config/?lang=${newLang}`);
    location.reload();
}
